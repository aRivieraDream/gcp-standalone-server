#!/bin/bash

gcloud deployment-manager deployments delete tableau-standalone-server
